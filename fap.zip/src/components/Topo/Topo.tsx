import Image from "next/image"
import styles from "@/styles/Topo.module.css"

interface TopoProps {
    titulo?: string;
}

export default function Topo({ titulo = "" }: TopoProps){
    return(
        <div className={styles.topo}>
            <div className={styles.topoImages}>
                <Image className={styles.topoStellantis} src={'/assets/logo-stellantis-branco.png'} alt={'Logo Stellantis'} width={473} height={102} />
                <Image src={'/assets/logo-centro-branco.png'} alt={'Logo Stellantis'} width={152} height={152} />
            </div>
            <div className={styles.topoTitulo}>
                {titulo}
            </div>
        </div>
    )
}